local file = io.open('./Abol.Abol', 'rb')
local bytecode = file:read('*all')
file:close()
loadstring(bytecode)()
